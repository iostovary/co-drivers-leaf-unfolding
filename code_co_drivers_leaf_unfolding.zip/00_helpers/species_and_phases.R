phase_list <- c("leaf unfolding")
species_list  <- c("FS","LD","PA","TC")
